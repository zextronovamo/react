const NavbarLinks = [
    {id: 1, label: "Setting", classes:[], path:"/setting"},
    {id: 2, label: "Account", classes:[], path:"/account"},
    {id: 3, label: "Logout", classes:[], path:"/logout"},
    
]

export default NavbarLinks;